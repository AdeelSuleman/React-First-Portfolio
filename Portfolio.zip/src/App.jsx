import {  useState } from "react";
import Contact from "./Components/Contact";
import Experience from "./Components/Experience";
import Hero from "./Components/Hero";
import Navbar from "./Components/Navbar";
import Project from "./Components/Project";
import Technologies from "./Components/Technologies";

const App = () => {


  const [rotation, setRotation] = useState(0); // Sirf X-axis rotation ke liye initial state

  // Mouse move hone par X-axis ki rotation ko update karo
  const handleMouseMove = (event) => {
    const { innerWidth } = window;
    
    // Mouse ka X position percentage mein le rahe hain
    const xAxis = (event.clientX / innerWidth) * 100;
    
    // Rotation ke angle ko set kar rahe hain
    setRotation((xAxis - 10) / 1.5); // Adjust kiya gaya value taake rotation zyada na ho
  };

  return (
    <div className="overflow-x-hidden text-stone-300 lg:px-5 antialiased"
      onMouseMove={handleMouseMove} 
      style={{
        transform: `rotateY(${rotation}deg)`, // Sirf Y-axis (horizontal) par rotation
        transition: 'transform 0.1s ease-out', 
      }} >
      <div className="fixed inset-0 -z-10">
        <div className="relative h-full w-full bg-black">
          <div className="absolute bottom-0 left-0 right-0 top-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)] bg-[size:14px_24px]">

          </div>
          <div className="absolute left-0 right-0 top-[-10%] h-[1000px] w-[1000px] rounded-full bg-[radial-gradient(circle_400px_at_50%_300px,#fbfbfb36,#000)]">

          </div>
        </div>
      </div>
      <div className="container mx-auto px-8">
        <Navbar/>
        <Hero/>
        <Technologies/>
        <Project/>
        <Experience/>
        <Contact/>
      </div>
    </div>
  );
};

export default App;
